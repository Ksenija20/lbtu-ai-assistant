export declare const VERSION = "6.16.0";
//# sourceMappingURL=version.d.ts.map