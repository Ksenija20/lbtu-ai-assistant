"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseNeverDef = parseNeverDef;
function parseNeverDef() {
    return {
        not: {},
    };
}
//# sourceMappingURL=never.js.map