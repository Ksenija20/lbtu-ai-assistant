export function parseAnyDef() {
    return {};
}
//# sourceMappingURL=any.mjs.map