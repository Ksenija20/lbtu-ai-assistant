import { ZodReadonlyDef } from 'zod/v3';
import { Refs } from "../Refs.js";
export declare const parseReadonlyDef: (def: ZodReadonlyDef<any>, refs: Refs) => import("../parseDef").JsonSchema7Type | undefined;
//# sourceMappingURL=readonly.d.ts.map