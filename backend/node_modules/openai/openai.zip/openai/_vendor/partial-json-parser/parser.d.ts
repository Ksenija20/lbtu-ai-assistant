declare class PartialJSON extends Error {
}
declare class MalformedJSON extends Error {
}
declare const partialParse: (input: string) => any;
export { partialParse, PartialJSON, MalformedJSON };
//# sourceMappingURL=parser.d.ts.map