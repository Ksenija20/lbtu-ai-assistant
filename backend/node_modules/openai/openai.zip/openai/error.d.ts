export * from "./core/error.js";
//# sourceMappingURL=error.d.ts.map