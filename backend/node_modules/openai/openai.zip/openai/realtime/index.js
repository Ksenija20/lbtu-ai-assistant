"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAIRealtimeError = void 0;
var internal_base_1 = require("./internal-base.js");
Object.defineProperty(exports, "OpenAIRealtimeError", { enumerable: true, get: function () { return internal_base_1.OpenAIRealtimeError; } });
//# sourceMappingURL=index.js.map