export { OpenAIRealtimeError } from "./internal-base.js";
//# sourceMappingURL=index.d.ts.map