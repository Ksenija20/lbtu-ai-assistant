export { OpenAIRealtimeError } from "./internal-base.mjs";
//# sourceMappingURL=index.mjs.map