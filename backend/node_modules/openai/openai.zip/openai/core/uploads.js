"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toFile = void 0;
var to_file_1 = require("../internal/to-file.js");
Object.defineProperty(exports, "toFile", { enumerable: true, get: function () { return to_file_1.toFile; } });
//# sourceMappingURL=uploads.js.map