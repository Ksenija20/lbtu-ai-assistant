// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
export class APIResource {
    constructor(client) {
        this._client = client;
    }
}
//# sourceMappingURL=resource.mjs.map