export const VERSION = '6.16.0'; // x-release-please-version
