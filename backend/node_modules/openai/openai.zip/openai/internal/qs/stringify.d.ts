import type { StringifyOptions } from "./types.js";
export declare function stringify(object: any, opts?: StringifyOptions): string;
//# sourceMappingURL=stringify.d.ts.map