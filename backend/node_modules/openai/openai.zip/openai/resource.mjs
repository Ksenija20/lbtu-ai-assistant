export * from "./core/resource.mjs";
//# sourceMappingURL=resource.mjs.map