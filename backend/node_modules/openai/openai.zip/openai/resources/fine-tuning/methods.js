"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Methods = void 0;
const resource_1 = require("../../core/resource.js");
class Methods extends resource_1.APIResource {
}
exports.Methods = Methods;
//# sourceMappingURL=methods.js.map