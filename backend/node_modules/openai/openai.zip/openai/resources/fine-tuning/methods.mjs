// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
export class Methods extends APIResource {
}
//# sourceMappingURL=methods.mjs.map