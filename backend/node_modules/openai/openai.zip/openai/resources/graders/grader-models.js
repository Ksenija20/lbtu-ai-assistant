"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.GraderModels = void 0;
const resource_1 = require("../../core/resource.js");
class GraderModels extends resource_1.APIResource {
}
exports.GraderModels = GraderModels;
//# sourceMappingURL=grader-models.js.map