// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
export class GraderModels extends APIResource {
}
//# sourceMappingURL=grader-models.mjs.map