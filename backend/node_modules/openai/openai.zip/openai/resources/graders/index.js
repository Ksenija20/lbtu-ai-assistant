"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Graders = exports.GraderModels = void 0;
var grader_models_1 = require("./grader-models.js");
Object.defineProperty(exports, "GraderModels", { enumerable: true, get: function () { return grader_models_1.GraderModels; } });
var graders_1 = require("./graders.js");
Object.defineProperty(exports, "Graders", { enumerable: true, get: function () { return graders_1.Graders; } });
//# sourceMappingURL=index.js.map