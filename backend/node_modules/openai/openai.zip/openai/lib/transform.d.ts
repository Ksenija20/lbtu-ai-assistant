import type { JSONSchema } from "./jsonschema.js";
export declare function toStrictJsonSchema(schema: JSONSchema): JSONSchema;
//# sourceMappingURL=transform.d.ts.map