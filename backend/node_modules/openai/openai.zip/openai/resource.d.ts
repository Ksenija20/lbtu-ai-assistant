export * from "./core/resource.js";
//# sourceMappingURL=resource.d.ts.map